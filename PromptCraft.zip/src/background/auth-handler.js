// Chrome 扩展 Supabase 认证处理器
// Chrome 扩展认证处理器 - 使用 chrome.identity.launchWebAuthFlow

// 导入认证服务
importScripts('utils/auth-service.js');