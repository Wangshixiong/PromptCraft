/**
 * UIManager - UI管理器
 * 职责: 负责所有与DOM相关的操作，包括元素管理、UI渲染和状态更新
 * 创建时间: 2025-06-25
 */

// UI管理器对象
const ui = {
    // DOM 元素引用
    loadingOverlay: document.getElementById('loadingOverlay'),
    mainView: document.getElementById('mainView'),
    formView: document.getElementById('formView'),
    addPromptBtn: document.getElementById('addPromptBtn'),
    searchInput: document.getElementById('searchInput'),
    promptsContainer: document.getElementById('promptsContainer'),
    filterContainer: document.getElementById('filterContainer'),
    backToListBtn: document.getElementById('backToListBtn'),
    cancelFormBtn: document.getElementById('cancelFormBtn'),
    savePromptBtn: document.getElementById('savePromptBtn'),
    formTitle: document.getElementById('formTitle'),
    promptIdInput: document.getElementById('promptIdInput'),
    promptTitleInput: document.getElementById('promptTitleInput'),
    promptContentInput: document.getElementById('promptContentInput'),
    promptCategoryInput: document.getElementById('promptCategoryInput'),
    promptCategorySelect: document.getElementById('promptCategorySelect'),
    settingsBtn: document.getElementById('settingsBtn'),
    settingsOverlay: document.getElementById('settingsOverlay'),
    settingsClose: document.getElementById('settingsClose'),
    importBtn: document.getElementById('importBtn'),
    exportBtn: document.getElementById('exportBtn'),
    downloadTemplateBtn: document.getElementById('downloadTemplateBtn'),
    fileInput: document.getElementById('fileInput'),
    // 版本日志相关元素
    versionNumber: document.getElementById('versionNumber'),
    versionNew: document.getElementById('versionNew'),
    versionLogOverlay: document.getElementById('versionLogOverlay'),
    versionLogClose: document.getElementById('versionLogClose'),
    versionLogBody: document.getElementById('versionLogBody'),
    
    // 当前视图状态
    currentView: null,
    
    /**
     * 切换视图显示
     * @param {string} viewId - 视图ID
     * @returns {boolean} 切换是否成功
     */
    showView(viewId) {
        try {
            // 隐藏所有视图
            document.querySelectorAll('.view').forEach(view => {
                view.classList.remove('active');
            });
            
            // 获取目标视图元素
            const targetView = document.getElementById(viewId);
            if (!targetView) {
                console.error(`错误：找不到视图元素 ID: ${viewId}`);
                return false;
            }
            
            // 显示目标视图
            targetView.classList.add('active');
            this.currentView = viewId;
            
            // 强制重绘以确保样式生效
            targetView.offsetHeight;
            
            // 智能检查视图显示状态（避免初始化时的误报）
            setTimeout(() => {
                // 确保元素仍然存在且是当前视图
                if (!targetView.parentNode || this.currentView !== viewId) {
                    return;
                }
                
                // 检查CSS是否已加载完成
                const isStylesLoaded = document.readyState === 'complete' && 
                                     getComputedStyle(document.body).fontFamily !== '';
                
                if (!isStylesLoaded) {
                    return;
                }
                
                const computedStyle = window.getComputedStyle(targetView);
                const isVisible = computedStyle.display !== 'none' && 
                                targetView.offsetWidth > 0 && 
                                targetView.offsetHeight > 0;
                
                // 只有在确实有问题且不是初始化阶段时才显示警告和重试
                if (!isVisible && targetView.classList.contains('active')) {
                    // 额外检查：确保不是在页面加载的前几秒内
                    const pageLoadTime = performance.now();
                    if (pageLoadTime > 3000) { // 页面加载3秒后才报警告
                        console.warn(`警告：视图 ${viewId} 可能未正确显示，尝试重新应用样式`);
                        // 重新应用active类
                        targetView.classList.remove('active');
                        // 使用requestAnimationFrame确保DOM更新
                        requestAnimationFrame(() => {
                            if (this.currentView === viewId) {
                                targetView.classList.add('active');
                            }
                        });
                    }
                }
            }, 300); // 增加延迟时间，确保CSS和动画完成
            
            return true;
        } catch (err) {
            console.error(`切换视图到 ${viewId} 时发生错误:`, err);
            return false;
        }
    },
    
    /**
     * 渲染提示词列表
     * @param {Array} promptsToRender - 要渲染的提示词数组
     */
    renderPrompts(promptsToRender) {
        try {
            // 清空骨架屏占位符和所有内容
            this.promptsContainer.innerHTML = '';

            if (promptsToRender.length === 0) {
                this.promptsContainer.innerHTML = `<div style="text-align: center; padding: 40px 20px; color: #64748b;"><i class="fas fa-inbox" style="font-size: 48px; margin-bottom: 16px;"></i><h3>空空如也</h3><p>点击上方按钮添加您的第一个提示词吧！</p></div>`;
                return;
            }

            promptsToRender.forEach((prompt, index) => {
                try {
                    if (!prompt || !prompt.id) {
                        console.error(`跳过无效提示词，索引: ${index}`, prompt);
                        return;
                    }
                    
                    const card = document.createElement('div');
                    card.className = 'prompt-card fade-in';
                    card.dataset.id = prompt.id;
                    card.innerHTML = `
                        <div class="prompt-card-header">
                            <div class="prompt-title">${this.escapeHtml(prompt.title || '无标题')}</div>
                            <button class="copy-btn" data-content="${this.escapeHtml(prompt.content || '')}">复制</button>
                        </div>
                        <div class="prompt-content">${this.escapeHtml(prompt.content || '')}</div>
                        <div class="card-footer">
                            <div class="meta-info">
                                ${prompt.category ? `<span class="prompt-category category-${this.getCategoryColor(prompt.category)}">${this.escapeHtml(prompt.category)}</span>` : ''}
                                <span class="creation-date">${this.formatDate(prompt.created_at)}</span>
                            </div>
                            <div class="card-actions">
                                <div class="actions-on-hover">
                                    <button class="action-btn edit-btn" data-id="${prompt.id}" title="编辑">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="action-btn delete-btn" data-id="${prompt.id}" title="删除">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    `;
                    this.promptsContainer.appendChild(card);
                } catch (cardErr) {
                    console.error(`渲染提示词卡片错误，索引: ${index}`, cardErr);
                }
            });
            
            this.addCardEventListeners();
        
        } catch (err) {
            console.error('渲染提示词时发生错误:', err);
            console.error('错误详情:', err.message, err.stack);
        }
    },

    /**
     * 格式化日期显示
     * @param {string} dateString - 日期字符串
     * @returns {string} 格式化后的日期
     */
    formatDate(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' });
    },

    /**
     * HTML转义函数
     * @param {string} text - 需要转义的文本
     * @returns {string} 转义后的文本
     */
    escapeHtml(text) {
        if (typeof text !== 'string') return '';
        return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    },

    /**
     * 获取分类颜色
     * @param {string} category - 分类名称
     * @returns {string} 颜色类名
     */
    getCategoryColor(category) {
         const colors = ['blue', 'green', 'purple', 'orange', 'pink', 'indigo'];
         let hash = 0;
         for (let i = 0; i < category.length; i++) {
             hash = category.charCodeAt(i) + ((hash << 5) - hash);
         }
         return colors[Math.abs(hash) % colors.length];
     },

    /**
     * HTML反转义函数
     * @param {string} text - 需要反转义的文本
     * @returns {string} 反转义后的文本
     */
    unescapeHtml(text) {
        if (typeof text !== 'string') return '';
        return text.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#039;/g, "'");
    },

    /**
     * 自动调整textarea高度以适应内容
     * @param {HTMLTextAreaElement} textarea - 需要调整高度的textarea元素
     */
    autoResizeTextarea(textarea) {
        // 重置高度为最小值，以便正确计算scrollHeight
        textarea.style.height = '120px';
        
        // 计算内容所需的高度
        const scrollHeight = textarea.scrollHeight;
        const maxHeight = parseInt(getComputedStyle(textarea).maxHeight);
        
        // 设置新高度，不超过最大高度
        if (scrollHeight <= maxHeight) {
            textarea.style.height = scrollHeight + 'px';
        } else {
            textarea.style.height = maxHeight + 'px';
        }
    },

    /**
     * 显示提示词预览弹窗
     * @param {Object} prompt - 提示词对象
     */
    showPreview(prompt) {
        const overlay = document.createElement('div');
        overlay.className = 'preview-overlay';
        
        const modal = document.createElement('div');
        modal.className = 'preview-modal';
        
        modal.innerHTML = `
            <div class="preview-header">
                <div class="preview-title-section">
                    <h2 class="preview-title">${this.escapeHtml(prompt.title || '无标题')}</h2>
                    ${prompt.category ? `<div class="preview-category">${this.escapeHtml(prompt.category)}</div>` : ''}
                </div>
                <button class="preview-close">&times;</button>
            </div>
            <div class="preview-body">
                <div class="preview-content">${this.escapeHtml(prompt.content || '')}</div>
            </div>
            <div class="preview-footer">
                <div class="preview-date">${this.formatDate(prompt.created_at)}</div>
                <button class="preview-copy-btn"><i class="fas fa-copy"></i> 复制</button>
            </div>
        `;
        
        overlay.appendChild(modal);
        document.body.appendChild(overlay);
        
        // 关闭按钮事件
        modal.querySelector('.preview-close').onclick = () => {
            overlay && overlay.remove();
        };
        
        // 点击遮罩关闭
        overlay.onclick = (e) => {
            if (e.target === overlay) {
                overlay && overlay.remove();
            }
        };
        
        // 复制按钮事件
        const copyBtn = modal.querySelector('.preview-copy-btn');
        copyBtn.onclick = () => {
            navigator.clipboard.writeText(prompt.content || '').then(() => {
                const originalText = copyBtn.innerHTML;
                copyBtn.innerHTML = '<i class="fas fa-check"></i> 已复制!';
                copyBtn.style.background = 'var(--success)';
                setTimeout(() => {
                    copyBtn.innerHTML = originalText;
                    copyBtn.style.background = '';
                }, 1500);
            });
        };
        
        // ESC键关闭
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                overlay && overlay.remove();
                document.removeEventListener('keydown', handleEsc);
            }
        };
        document.addEventListener('keydown', handleEsc);
    },

    /**
     * 更新分类筛选按钮
     */
    updateFilterButtons() {
        const categories = ['全部', ...new Set(allPrompts.map(p => p.category).filter(Boolean))];
        this.filterContainer.innerHTML = '';
        categories.forEach(cat => {
            const btn = document.createElement('button');
            btn.className = 'filter-btn';
            if (cat === '全部') btn.classList.add('active');
            btn.textContent = cat;
            btn.addEventListener('click', (e) => app.handleFilter(cat, e));
            this.filterContainer.appendChild(btn);
        });
        
        // 更新分类下拉选项
        this.updateCategoryOptions();
    },

    /**
     * 更新分类下拉选项
     */
    updateCategoryOptions() {
        const existingCategories = [...new Set(allPrompts.map(p => p.category).filter(Boolean))];
        this.promptCategorySelect.innerHTML = '<option value="">选择分类</option>';
        existingCategories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            this.promptCategorySelect.appendChild(option);
        });
    },

    /**
     * 设置分类输入框的自动建议功能
     */
    setupCategoryInput() {
        // 创建分类建议容器
        const suggestionContainer = document.createElement('div');
        suggestionContainer.style.cssText = `
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--card-light);
            border: 1px solid var(--border-light);
            border-radius: 8px;
            max-height: 150px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        `;
        
        // 设置分类输入框的父容器为相对定位
        this.promptCategoryInput.parentElement.style.position = 'relative';
        this.promptCategoryInput.parentElement.appendChild(suggestionContainer);

        // 监听输入框聚焦事件
        this.promptCategoryInput.addEventListener('focus', () => {
            updateCategorySuggestions();
        });
        
        // 输入框输入时更新建议
        this.promptCategoryInput.addEventListener('input', () => {
            updateCategorySuggestions();
        });
        
        // 点击其他地方时隐藏建议
        document.addEventListener('click', (e) => {
            if (!this.promptCategoryInput.contains(e.target) && !suggestionContainer.contains(e.target)) {
                suggestionContainer.style.display = 'none';
            }
        });
        
        const updateCategorySuggestions = () => {
            const existingCategories = [...new Set(allPrompts.map(p => p.category).filter(Boolean))];
            const inputValue = this.promptCategoryInput.value.toLowerCase();
            
            // 过滤匹配的分类
            const filteredCategories = existingCategories.filter(cat => 
                cat.toLowerCase().includes(inputValue)
            );
            
            if (filteredCategories.length > 0) {
                suggestionContainer.innerHTML = '';
                filteredCategories.forEach(category => {
                    const item = document.createElement('div');
                    item.style.cssText = `
                        padding: 8px 12px;
                        cursor: pointer;
                        border-bottom: 1px solid var(--border-light);
                        color: var(--text-light);
                        background-color: var(--background-light);
                    `;
                    item.textContent = category;
                    
                    // 暗色模式样式
                    if (document.body.classList.contains('dark-mode')) {
                        item.style.color = 'var(--text-dark)';
                        item.style.backgroundColor = 'var(--background-dark)';
                        item.style.borderColor = 'var(--border-dark)';
                    }
                    
                    item.addEventListener('mouseenter', () => {
                        item.style.backgroundColor = 'var(--primary-color)';
                        item.style.color = 'white';
                    });
                    
                    item.addEventListener('mouseleave', () => {
                        item.style.backgroundColor = document.body.classList.contains('dark-mode') ? 'var(--background-dark)' : 'var(--background-light)';
                        item.style.color = document.body.classList.contains('dark-mode') ? 'var(--text-dark)' : 'var(--text-light)';
                    });
                    
                    item.addEventListener('click', () => {
                        this.promptCategoryInput.value = category;
                        suggestionContainer.style.display = 'none';
                    });
                    
                    suggestionContainer.appendChild(item);
                });
                suggestionContainer.style.display = 'block';
            } else {
                suggestionContainer.style.display = 'none';
            }
        }
    },



    /**
     * 为提示词卡片添加事件监听器
     */
    addCardEventListeners() {
        // 添加卡片点击预览事件
        document.querySelectorAll('.prompt-card').forEach(card => {
            card.addEventListener('click', (e) => {
                // 如果点击的是按钮，不触发预览
                if (e.target.closest('.copy-btn, .edit-btn, .delete-btn')) {
                    return;
                }
                
                const id = card.dataset.id;
                const prompt = allPrompts.find(p => p.id == id);
                if (prompt) {
                    this.showPreview(prompt);
                }
            });
        });

        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = e.currentTarget.dataset.id;
                const prompt = allPrompts.find(p => p.id == id);
                if (prompt) {
                    this.promptIdInput.value = prompt.id;
                    this.promptTitleInput.value = prompt.title;
                    this.promptContentInput.value = prompt.content;
                    this.promptCategoryInput.value = prompt.category || '';
                    this.promptCategorySelect.value = prompt.category || '';
                    this.promptCategorySelect.style.display = 'none';
                    this.promptCategoryInput.style.display = 'block';
                    this.formTitle.textContent = '编辑提示词';
                    this.showView('formView');
                    // 调整textarea高度以适应内容
                    this.autoResizeTextarea(this.promptContentInput);
                }
            });
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = e.currentTarget.dataset.id;
                app.handleDeletePrompt(id);
            });
        });

        document.querySelectorAll('.copy-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const content = e.currentTarget.dataset.content;
                navigator.clipboard.writeText(this.unescapeHtml(content)).then(() => {
                    // 添加复制成功的视觉反馈
                     btn.classList.add('copied');
                     const originalText = btn.innerHTML;
                     btn.innerHTML = '已复制!';
                     btn.style.background = 'var(--success)';
                     
                     // 2秒后恢复原状
                     setTimeout(() => {
                         btn.classList.remove('copied');
                         btn.innerHTML = originalText;
                         btn.style.background = '';
                     }, 2000);
                }).catch(err => {
                    console.error('复制失败:', err);
                });
            });
        });
    },

    // 认证与同步UI函数
    /**
     * 设置登录按钮的加载状态
     * @param {boolean} isLoading - 是否显示加载状态
     */
    setLoginButtonLoading(isLoading, progressText = '') {
        const googleSignInBtn = document.getElementById('googleSignInBtn');
        if (!googleSignInBtn) return;
        
        const googleIcon = googleSignInBtn.querySelector('.google-icon');
        const btnText = googleSignInBtn.querySelector('.btn-text');
        
        if (isLoading) {
            // 添加加载状态类
            googleSignInBtn.classList.add('loading');
            
            // 隐藏Google图标，显示加载动画
            if (googleIcon) {
                googleIcon.style.display = 'none';
            }
            
            // 创建并插入加载动画
            const existingSpinner = googleSignInBtn.querySelector('.loading-spinner');
            if (!existingSpinner) {
                const spinner = document.createElement('div');
                spinner.className = 'loading-spinner';
                googleSignInBtn.insertBefore(spinner, btnText);
            }
            
            // 更改按钮文字
            if (btnText) {
                btnText.textContent = progressText || '正在登录...';
            }
        } else {
            // 移除加载状态类
            googleSignInBtn.classList.remove('loading');
            
            // 显示Google图标
            if (googleIcon) {
                googleIcon.style.display = 'block';
            }
            
            // 移除加载动画
            const spinner = googleSignInBtn.querySelector('.loading-spinner');
            if (spinner) {
                spinner.remove();
            }
            
            // 恢复按钮文字
            if (btnText) {
                btnText.textContent = '使用 Google 登录';
            }
        }
    },

    /**
     * 根据认证状态更新UI
     * @param {Object|null} session - 用户会话信息
     */
    updateUIForAuthState(session) {
        // 设置页面元素
        const loggedOutSection = document.getElementById('loggedOutSection');
        const loggedInSection = document.getElementById('loggedInSection');
        const userAvatar = document.getElementById('userAvatar');
        const defaultAvatar = document.getElementById('defaultAvatar');
        const userName = document.getElementById('userName');
        const userEmail = document.getElementById('userEmail');
        
        if (session && session.user) {
            // 已登录状态
            const user = session.user;
            
            // 更新设置页面中的用户信息
            if (loggedInSection) loggedInSection.style.display = 'block';
            if (loggedOutSection) loggedOutSection.style.display = 'none';
            
            // 更新用户头像
            if (userAvatar && user.user_metadata?.avatar_url) {
                const avatarImg = userAvatar.querySelector('.avatar-img');
                if (avatarImg) {
                    avatarImg.src = user.user_metadata.avatar_url;
                    userAvatar.style.display = 'block';
                    if (defaultAvatar) defaultAvatar.style.display = 'none';
                }
            } else {
                if (userAvatar) userAvatar.style.display = 'none';
                if (defaultAvatar) {
                    defaultAvatar.style.display = 'flex';
                    // 设置默认头像的首字母
                    const firstLetter = (user.email || 'U').charAt(0).toUpperCase();
                    defaultAvatar.textContent = firstLetter;
                }
            }
            
            // 更新用户昵称和邮箱
            if (userName) {
                // 优先使用用户元数据中的姓名，否则使用邮箱前缀
                const displayName = user.user_metadata?.full_name || 
                                   user.user_metadata?.name || 
                                   (user.email ? user.email.split('@')[0] : '用户');
                userName.textContent = displayName;
                userName.title = displayName; // 添加hover显示完整用户名
            }
            
            if (userEmail) {
                const email = user.email || '未知邮箱';
                userEmail.textContent = email;
                userEmail.title = email; // 添加hover显示完整邮箱
            }
            
            // 初始化同步时间显示
            this.updateSyncTime();
            
            // 更新全局用户状态
            currentUser = {
                id: user.id,
                email: user.email,
                avatar_url: user.user_metadata?.avatar_url
            };
        } else {
            // 未登录状态
            // 更新设置页面状态
            if (loggedOutSection) loggedOutSection.style.display = 'block';
            if (loggedInSection) loggedInSection.style.display = 'none';
            
            // 保持本地用户状态以确保本地功能正常
            if (!currentUser) {
                currentUser = {
                    id: 'local-user',
                    email: 'local@example.com'
                };
            }
        }
    },

    /**
     * 更新同步时间显示
     */
    async updateSyncTime() {
        const syncTimeElement = document.getElementById('syncTime');
        if (syncTimeElement) {
            try {
                console.log('[DEBUG] 开始获取最后同步时间...');
                // 从存储中获取真实的最后同步时间
                const response = await chrome.runtime.sendMessage({
                    type: 'GET_LAST_SYNC_TIME'
                });
                
                console.log('[DEBUG] GET_LAST_SYNC_TIME 响应:', response);
                
                if (response && response.success && response.data) {
                    console.log('[DEBUG] 同步时间数据:', response.data);
                    const syncTime = new Date(response.data);
                    console.log('[DEBUG] 解析后的时间对象:', syncTime);
                    console.log('[DEBUG] UTC时间:', syncTime.toISOString());
                    console.log('[DEBUG] 本地时间:', syncTime.toString());
                    
                    // 使用北京时间格式化
                    const timeString = syncTime.toLocaleString('zh-CN', {
                        timeZone: 'Asia/Shanghai',
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                        hour12: false
                    });
                    console.log('[DEBUG] 格式化后的时间字符串:', timeString);
                    syncTimeElement.textContent = `最后同步时间: ${timeString}`;
                } else {
                    console.log('[DEBUG] 没有同步时间数据，显示"尚未同步"');
                    console.log('[DEBUG] response.success:', response?.success);
                    console.log('[DEBUG] response.data:', response?.data);
                    syncTimeElement.textContent = '尚未同步';
                }
            } catch (error) {
                console.error('[DEBUG] 获取同步时间失败:', error);
                syncTimeElement.textContent = '同步时间获取失败';
            }
        } else {
            console.error('[DEBUG] 找不到syncTime元素');
        }
    },

    /**
     * 更新同步状态
     * @param {string} status - 同步状态
     * @param {string} lastSyncTime - 最后同步时间
     */
    updateSyncStatus(status, lastSyncTime) {
        const syncTimeElement = document.getElementById('syncTime');
        
        switch (status) {
            case 'syncing':
                if (syncTimeElement) {
                    syncTimeElement.textContent = '正在同步...';
                }
                break;
                
            case 'success':
                if (lastSyncTime) {
                    const syncTime = new Date(lastSyncTime);
                    const timeString = syncTime.toLocaleString('zh-CN', {
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                    });
                    if (syncTimeElement) {
                        syncTimeElement.textContent = `最后同步时间: ${timeString}`;
                    }
                } else {
                    this.updateSyncTime();
                }
                this.showToast('云端同步完成', 'success');
                break;
                
            case 'error':
                if (syncTimeElement) {
                    syncTimeElement.textContent = '同步失败';
                }
                this.showToast('同步失败，请稍后重试', 'error');
                break;
                
            case 'idle':
            default:
                if (syncTimeElement) {
                    syncTimeElement.textContent = '尚未同步';
                }
                break;
        }
    },

    /**
     * 更新同步UI状态（保留用于兼容性）
     * @param {string} status - 同步状态
     * @param {string} message - 状态消息
     */
    updateSyncUI(status, message) {
        // 对于新的UI，只需要更新同步时间
        if (status === 'success' && message && message.includes('同步完成')) {
            this.updateSyncTime();
            this.showToast('云端同步完成，数据已更新', 'success');
        }
    },

    /**
     * 检测系统主题
     * @returns {string} 'dark' 或 'light'
     */
    getSystemTheme() {
        return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    },

    /**
     * 应用主题
     * @param {string} mode - 主题模式：'light', 'dark', 'auto'
     */
    applyTheme(mode) {
        const actualTheme = mode === 'auto' ? this.getSystemTheme() : mode;
        const isDark = actualTheme === 'dark';
        
        if (isDark) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
        
        // 更新主题选择器状态
        this.updateThemeSelector(mode);
    },

    /**
     * 更新主题选择器状态
     * @param {string} mode - 主题模式
     */
    updateThemeSelector(mode) {
        const themeOptions = document.querySelectorAll('.theme-option');
        themeOptions.forEach(option => {
            option.classList.remove('active');
            if (option.dataset.theme === mode) {
                option.classList.add('active');
            }
        });
    },

    /**
     * 显示Toast提示消息
     * @param {string} message - 提示消息内容
     * @param {string} type - 消息类型：'success', 'error', 'warning', 'info'
     * @param {number} duration - 显示持续时间（毫秒）
     */
    showToast(message, type = 'success', duration = 1500) {
        const toastContainer = document.getElementById('toastContainer');
        if (!toastContainer) return;
        
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        
        const iconMap = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        
        toast.innerHTML = `
            <i class="${iconMap[type] || iconMap.success}"></i>
            <span>${message}</span>
        `;
        
        toastContainer.appendChild(toast);
        
        // 触发显示动画
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // 自动移除
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toastContainer.contains(toast)) {
                    toastContainer.removeChild(toast);
                }
            }, 300);
        }, duration);
    },

    /**
     * 兼容性函数，保持原有的showCustomAlert接口
     * @param {string} message - 提示消息
     * @returns {Promise<void>}
     */
    showCustomAlert(message) {
        this.showToast(message, 'info');
        return Promise.resolve();
    },

    /**
     * 显示自定义确认弹窗
     * @param {string} message - 确认消息
     * @param {string} title - 弹窗标题
     * @returns {Promise<boolean>} 用户选择结果
     */
    showCustomConfirm(message, title = '确认操作') {
        return new Promise((resolve) => {
            const overlay = document.getElementById('confirmOverlay');
            const titleElement = document.getElementById('confirmTitle');
            const messageElement = document.getElementById('confirmMessage');
            const cancelBtn = document.getElementById('confirmCancelBtn');
            const okBtn = document.getElementById('confirmOkBtn');
            
            if (!overlay || !titleElement || !messageElement || !cancelBtn || !okBtn) {
                console.error('确认弹窗元素未找到');
                resolve(false);
                return;
            }
            
            // 设置内容
            titleElement.textContent = title;
            messageElement.textContent = message;
            
            // 显示弹窗
            overlay.style.display = 'flex';
            
            // 清除之前的事件监听器
            const newCancelBtn = cancelBtn.cloneNode(true);
            const newOkBtn = okBtn.cloneNode(true);
            cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);
            okBtn.parentNode.replaceChild(newOkBtn, okBtn);
            
            // 添加事件监听器
            newOkBtn.onclick = () => {
                overlay.style.display = 'none';
                resolve(true);
            };
            
            newCancelBtn.onclick = () => {
                overlay.style.display = 'none';
                resolve(false);
            };
            
            // 点击遮罩层关闭
            overlay.onclick = (e) => {
                if (e.target === overlay) {
                    overlay.style.display = 'none';
                    resolve(false);
                }
            };
        });
    },

    // ===== 版本日志UI函数 =====
    
    /**
     * 显示版本日志弹窗
     */
    async showVersionLog() {
        const versionData = await app.loadVersionLogData();
        if (!versionData) {
            console.error('无法加载版本日志数据');
            return;
        }

        // 清空之前的内容
        this.versionLogBody.innerHTML = '';

        // 按版本号倒序显示（最新版本在前）
        const sortedVersions = versionData.versions.sort((a, b) => {
            // 简单的版本号比较（假设格式为 x.y.z）
            const aVersion = a.version.split('.').map(Number);
            const bVersion = b.version.split('.').map(Number);
            
            for (let i = 0; i < Math.max(aVersion.length, bVersion.length); i++) {
                const aPart = aVersion[i] || 0;
                const bPart = bVersion[i] || 0;
                if (aPart !== bPart) {
                    return bPart - aPart; // 倒序
                }
            }
            return 0;
        });

        // 生成版本日志HTML
        sortedVersions.forEach(version => {
            const versionItem = document.createElement('div');
            versionItem.className = 'version-item';
            
            const versionHeader = document.createElement('div');
            versionHeader.className = 'version-header';
            
            const versionTitle = document.createElement('h3');
            versionTitle.className = 'version-title';
            versionTitle.textContent = `v${version.version}`;
            
            const versionDate = document.createElement('span');
            versionDate.className = 'version-date';
            versionDate.textContent = version.date;
            
            versionHeader.appendChild(versionTitle);
            versionHeader.appendChild(versionDate);
            
            const versionContent = document.createElement('div');
            versionContent.className = 'version-content';
            
            if (version.title) {
                const titleElement = document.createElement('h4');
                titleElement.className = 'version-subtitle';
                titleElement.textContent = version.title;
                versionContent.appendChild(titleElement);
            }
            
            const changesList = document.createElement('ul');
            changesList.className = 'version-changes';
            
            version.changes.forEach(change => {
                const changeItem = document.createElement('li');
                changeItem.textContent = change;
                changesList.appendChild(changeItem);
            });
            
            versionContent.appendChild(changesList);
            
            versionItem.appendChild(versionHeader);
            versionItem.appendChild(versionContent);
            
            this.versionLogBody.appendChild(versionItem);
        });

        // 显示弹窗
        this.versionLogOverlay.style.display = 'flex';
        
        // 标记用户已查看最新版本
        await this.markVersionAsViewed(versionData.currentVersion);
    },

    /**
     * 隐藏版本日志弹窗
     */
    hideVersionLog() {
        this.versionLogOverlay.style.display = 'none';
    },

    /**
     * 检查是否有新版本
     */
    async checkForNewVersion() {
        const versionData = await app.loadVersionLogData();
        if (!versionData) {
            return;
        }

        try {
            // 从background script获取用户最后查看的版本
            const response = await chrome.runtime.sendMessage({ type: 'GET_LAST_VIEWED_VERSION' });
            
            if (response && response.success) {
                const lastViewedVersion = response.data;
                
                // 如果用户从未查看过版本日志，或者当前版本比最后查看的版本新
                if (!lastViewedVersion || versionData.currentVersion !== lastViewedVersion) {
                    // 显示NEW标识
                    this.versionNew.style.display = 'inline-block';
                } else {
                    // 隐藏NEW标识
                    this.versionNew.style.display = 'none';
                }
            } else {
                console.error('获取最后查看版本失败:', response?.error);
            }
        } catch (error) {
            console.error('检查新版本失败:', error);
        }
    },

    /**
     * 标记版本为已查看
     * @param {string} version 版本号
     */
    async markVersionAsViewed(version) {
        try {
            const response = await chrome.runtime.sendMessage({ 
                type: 'SET_LAST_VIEWED_VERSION', 
                payload: version 
            });
            
            if (response && response.success) {
                // 隐藏NEW标识
                this.versionNew.style.display = 'none';
            } else {
                console.error('设置最后查看版本失败:', response?.error);
            }
        } catch (error) {
            console.error('标记版本为已查看失败:', error);
        }
    },

    // ===== 加载动画UI函数 =====
    
    /**
     * 显示加载动画
     */
    showLoading() {
        this.loadingOverlay.style.display = 'flex';
    },

    /**
     * 隐藏加载动画
     */
    hideLoading() {
        this.loadingOverlay.style.display = 'none';
    },

    /**
     * 强制隐藏加载动画
     */
    forceHideLoading() {
        this.hideLoading();
        if (window.loadingTimeout) {
            clearTimeout(window.loadingTimeout);
            window.loadingTimeout = null;
        }
    },

    /**
     * 安全显示加载动画（带超时保护）
     */
    safeShowLoading() {
        this.showLoading();
        // 10秒后强制隐藏loading
        if (window.loadingTimeout) clearTimeout(window.loadingTimeout);
        window.loadingTimeout = setTimeout(() => {
            this.forceHideLoading();
            // 如果没有用户设置，显示主界面
            if (!window.currentUser) {
                this.showView('mainView');
            }
        }, 10000);
    },

    // 导出ui对象供其他模块使用
    getUI() {
        return this;
    }
};

// 暴露ui对象供其他模块使用
window.ui = ui;